ข้างในจะมี 2 folder
folder WebApps จะมี homework7_index จะอยู่ใน IIS ที่พอร์ต 8080
folder WebSites จะมี homework7_aspx จะอยู่ใน IIS ที่พอร์ต 8081

ถ้าจะดูไฟล์.aspx ให้เอาไปใส่ใน IIS ที่พอร์ต 8081 ก่อน

